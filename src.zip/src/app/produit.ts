export class Produit {
    id:number;
    nom:string;
    description:string;
    prix:number;
    image:string;
    categorie:number;
    version:number;
}
