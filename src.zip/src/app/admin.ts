export interface Admin {
    id: number;
    email: string;
    nom: string;
    pass: string;
    version: number;
  }
  