import { Ligne } from './ligne';

describe('Ligne', () => {
  it('should create an instance', () => {
    expect(new Ligne()).toBeTruthy();
  });
});
