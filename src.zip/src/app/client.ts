export class Client {
  id: number;
  pass: string;
  nom: string;
  prenom: string;
  adresse: string;
  email: string;
  version: number;
}
